n: int = int(input())

for i in range(1, n + 1):
    s = input()
    print((s + "\n") * i, end="")
