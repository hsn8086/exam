print(2**9)
